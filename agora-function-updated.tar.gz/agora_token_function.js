const { RtcTokenBuilder, RtcRole } = require('agora-access-token');

// Agora credentials (set these in Appwrite Function Environment Variables)
const APP_ID = process.env.AGORA_APP_ID || '3ccc264b24df4b5f91fa35741ea6e0b8';
const APP_CERTIFICATE = process.env.AGORA_APP_CERTIFICATE; // You'll need to get this from Agora Console

/**
 * Appwrite Function to generate Agora RTC tokens
 * 
 * Expected payload:
 * {
 *   "channel": "arena",
 *   "uid": 0,
 *   "role": "publisher", // "publisher" or "subscriber"
 *   "expireTime": 3600   // seconds (optional, defaults to 1 hour)
 * }
 */
module.exports = async ({ req, res, log, error }) => {
  try {
    log('🚀 Agora Token Generator function started');
    
    // Get environment variables
    const appId = process.env.AGORA_APP_ID;
    const appCertificate = process.env.AGORA_APP_CERTIFICATE;
    
    log(`App ID: ${appId ? 'Set' : 'Missing'}`);
    log(`App Certificate: ${appCertificate ? 'Set' : 'Missing'}`);
    
    if (!appId || !appCertificate) {
      error('Missing AGORA_APP_ID or AGORA_APP_CERTIFICATE environment variables');
      return res.json({
        success: false,
        error: 'Server configuration error'
      }, 500);
    }

    // Parse request data - try multiple sources
    let requestData = {};
    
    log('Raw req object keys: ' + Object.keys(req).join(', '));
    log('Request method: ' + req.method);
    log('Request headers: ' + JSON.stringify(req.headers || {}));
    
    // Try different ways to get the request data
    if (req.body) {
      log('Found req.body: ' + req.body);
      try {
        requestData = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
      } catch (e) {
        log('Error parsing req.body: ' + e.message);
      }
    }
    
    if (req.payload) {
      log('Found req.payload: ' + JSON.stringify(req.payload));
      requestData = req.payload;
    }
    
    if (req.variables) {
      log('Found req.variables: ' + JSON.stringify(req.variables));
      requestData = { ...requestData, ...req.variables };
    }
    
    // Check query parameters for GET requests
    if (req.query) {
      log('Found req.query: ' + JSON.stringify(req.query));
      requestData = { ...requestData, ...req.query };
    }
    
    log('Final request data: ' + JSON.stringify(requestData));
    
    const { channelName, uid, role } = requestData;
    
    if (!channelName) {
      log('No channelName provided, using default: arena');
      // Use default values for testing
      requestData.channelName = 'arena';
      requestData.uid = 12345;
      requestData.role = 'publisher';
    }
    
    // Set default values
    const userUid = requestData.uid || 0;
    const userRole = requestData.role === 'publisher' ? RtcRole.PUBLISHER : RtcRole.SUBSCRIBER;
    const finalChannelName = requestData.channelName || 'arena';
    
    log(`Generating token for channel: ${finalChannelName}, uid: ${userUid}, role: ${requestData.role || 'subscriber'}`);
    
    // Token expires in 24 hours
    const expirationTimeInSeconds = Math.floor(Date.now() / 1000) + (24 * 60 * 60);
    
    // Generate token
    const token = RtcTokenBuilder.buildTokenWithUid(
      appId,
      appCertificate,
      finalChannelName,
      userUid,
      userRole,
      expirationTimeInSeconds
    );

    log(`Successfully generated token: ${token.substring(0, 50)}...`);

    return res.json({
      success: true,
      token: token,
      expiration: expirationTimeInSeconds,
      channelName: finalChannelName,
      uid: userUid,
      debug: {
        receivedData: requestData,
        appIdPresent: !!appId,
        appCertificatePresent: !!appCertificate
      }
    });

  } catch (err) {
    error('Error generating Agora token: ' + err.message);
    log('Full error: ' + JSON.stringify(err));
    return res.json({
      success: false,
      error: 'Failed to generate token: ' + err.message
    }, 500);
  }
}; 