import { Client, Databases, Query } from 'node-appwrite';

// Simple timer ticker that directly updates database without calling other functions
export default async ({ req, res, log, error }) => {
  try {
    log('Simple Timer Ticker: Starting...');
    
    // Initialize Appwrite client
    const client = new Client()
      .setEndpoint(process.env.APPWRITE_FUNCTION_ENDPOINT)
      .setProject(process.env.APPWRITE_FUNCTION_PROJECT_ID)
      .setKey(process.env.APPWRITE_API_KEY);

    const databases = new Databases(client);
    const DATABASE_ID = process.env.APPWRITE_DATABASE_ID;

    // Simple test - just list timers
    const timers = await databases.listDocuments(
      DATABASE_ID,
      'timers',
      [Query.limit(5)]
    );

    log(`Found ${timers.documents.length} timers`);

    return res.json({
      success: true,
      message: 'Simple ticker working',
      timerCount: timers.documents.length,
      timestamp: new Date().toISOString()
    });

  } catch (err) {
    error(`Simple Timer Ticker Error: ${err.message}`);
    return res.json({
      success: false,
      error: err.message
    }, 500);
  }
};