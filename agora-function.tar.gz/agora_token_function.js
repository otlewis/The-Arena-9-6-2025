const { RtcTokenBuilder, RtcRole } = require('agora-access-token');

// Agora credentials (set these in Appwrite Function Environment Variables)
const APP_ID = process.env.AGORA_APP_ID || '3ccc264b24df4b5f91fa35741ea6e0b8';
const APP_CERTIFICATE = process.env.AGORA_APP_CERTIFICATE; // You'll need to get this from Agora Console

/**
 * Appwrite Function to generate Agora RTC tokens
 * 
 * Expected payload:
 * {
 *   "channel": "arena",
 *   "uid": 0,
 *   "role": "publisher", // "publisher" or "subscriber"
 *   "expireTime": 3600   // seconds (optional, defaults to 1 hour)
 * }
 */
module.exports = async ({ req, res, log, error }) => {
  try {
    // Get environment variables
    const appId = process.env.AGORA_APP_ID;
    const appCertificate = process.env.AGORA_APP_CERTIFICATE;
    
    if (!appId || !appCertificate) {
      error('Missing AGORA_APP_ID or AGORA_APP_CERTIFICATE environment variables');
      return res.json({
        success: false,
        error: 'Server configuration error'
      }, 500);
    }

    // Parse request body
    const { channelName, uid, role } = JSON.parse(req.body || '{}');
    
    if (!channelName) {
      return res.json({
        success: false,
        error: 'channelName is required'
      }, 400);
    }

    // Set default values
    const userUid = uid || 0;
    const userRole = role === 'publisher' ? RtcRole.PUBLISHER : RtcRole.SUBSCRIBER;
    
    // Token expires in 24 hours
    const expirationTimeInSeconds = Math.floor(Date.now() / 1000) + (24 * 60 * 60);
    
    // Generate token
    const token = RtcTokenBuilder.buildTokenWithUid(
      appId,
      appCertificate,
      channelName,
      userUid,
      userRole,
      expirationTimeInSeconds
    );

    log(`Generated token for channel: ${channelName}, uid: ${userUid}, role: ${role || 'subscriber'}`);

    return res.json({
      success: true,
      token: token,
      expiration: expirationTimeInSeconds,
      channelName: channelName,
      uid: userUid
    });

  } catch (err) {
    error('Error generating Agora token: ' + err.message);
    return res.json({
      success: false,
      error: 'Failed to generate token'
    }, 500);
  }
}; 