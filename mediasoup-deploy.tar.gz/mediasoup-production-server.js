const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const mediasoup = require('mediasoup');
const cors = require('cors');

// Express app
const app = express();
app.use(cors());
app.use(express.json());

// HTTP server for production
const server = http.createServer(app);
console.log(`🔓 HTTP MediaSoup server starting on port ${process.env.PORT || 3001}`);

const io = socketIo(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

// MediaSoup configuration for Linode
const mediasoupConfig = {
  numWorkers: 4, // Adjust based on server specs
  worker: {
    rtcMinPort: 10000,
    rtcMaxPort: 10100,
    logLevel: 'warn',
    logTags: ['info', 'ice', 'dtls', 'rtp', 'srtp', 'rtcp'],
  },
  router: {
    mediaCodecs: [
      {
        kind: 'audio',
        mimeType: 'audio/opus',
        clockRate: 48000,
        channels: 2,
      },
      {
        kind: 'video',
        mimeType: 'video/VP8',
        clockRate: 90000,
        parameters: {
          'x-google-start-bitrate': 1000,
        },
      },
      {
        kind: 'video',
        mimeType: 'video/h264',
        clockRate: 90000,
        parameters: {
          'packetization-mode': 1,
          'profile-level-id': '4d0032',
          'level-asymmetry-allowed': 1,
          'x-google-start-bitrate': 1000,
        },
      },
    ],
  },
  webRtcTransport: {
    listenIps: [
      {
        ip: '0.0.0.0',
        announcedIp: process.env.ANNOUNCED_IP || '172.236.109.9', // Your Linode IP
      },
    ],
    maxIncomingBitrate: 1500000,
    initialAvailableOutgoingBitrate: 1000000,
  },
};

// MediaSoup setup
let mediasoupWorkers = [];
let nextMediasoupWorkerIdx = 0;

// Room management
const rooms = new Map();

class Room {
  constructor(roomId) {
    this.id = roomId;
    this.router = null;
    this.peers = new Map();
  }

  async initialize() {
    const worker = getMediasoupWorker();
    this.router = await worker.createRouter({
      mediaCodecs: mediasoupConfig.router.mediaCodecs,
    });
    console.log(`📡 Router created for room ${this.id}`);
  }

  addPeer(peerId, socket) {
    const peer = {
      id: peerId,
      socket: socket,
      transports: new Map(),
      producers: new Map(),
      consumers: new Map(),
    };
    this.peers.set(peerId, peer);
    return peer;
  }

  removePeer(peerId) {
    const peer = this.peers.get(peerId);
    if (peer) {
      // Clean up transports, producers, consumers
      peer.transports.forEach(transport => transport.close());
      peer.producers.forEach(producer => producer.close());
      peer.consumers.forEach(consumer => consumer.close());
      this.peers.delete(peerId);
    }
  }
}

// Initialize MediaSoup workers
async function initializeMediaSoup() {
  console.log(`🏭 Creating ${mediasoupConfig.numWorkers} MediaSoup workers...`);
  
  for (let i = 0; i < mediasoupConfig.numWorkers; i++) {
    const worker = await mediasoup.createWorker({
      logLevel: mediasoupConfig.worker.logLevel,
      logTags: mediasoupConfig.worker.logTags,
      rtcMinPort: mediasoupConfig.worker.rtcMinPort,
      rtcMaxPort: mediasoupConfig.worker.rtcMaxPort,
    });

    worker.on('died', () => {
      console.error(`❌ MediaSoup worker ${i} died, exiting in 2 seconds...`);
      setTimeout(() => process.exit(1), 2000);
    });

    mediasoupWorkers.push(worker);
    console.log(`✅ MediaSoup worker ${i} created`);
  }

  console.log(`🎉 All ${mediasoupConfig.numWorkers} MediaSoup workers created successfully`);
}

function getMediasoupWorker() {
  const worker = mediasoupWorkers[nextMediasoupWorkerIdx];
  if (++nextMediasoupWorkerIdx === mediasoupWorkers.length) {
    nextMediasoupWorkerIdx = 0;
  }
  return worker;
}

// Socket.IO connection handling
io.on('connection', (socket) => {
  console.log(`🔌 Client connected: ${socket.id}`);

  socket.on('join-room', async (data) => {
    try {
      const { roomId, userId } = data;
      console.log(`👥 ${userId} joining room: ${roomId}`);
      
      socket.join(roomId);
      
      // Get or create room
      let room = rooms.get(roomId);
      if (!room) {
        room = new Room(roomId);
        await room.initialize();
        rooms.set(roomId, room);
      }
      
      // Add peer to room
      const peer = room.addPeer(socket.id, socket);
      
      // Get router RTP capabilities
      const rtpCapabilities = room.router.rtpCapabilities;
      
      socket.emit('room-joined', { rtpCapabilities });
      socket.to(roomId).emit('peer-joined', { peerId: socket.id });
      
      console.log(`✅ ${userId} joined room ${roomId}`);
      
    } catch (error) {
      console.error('❌ Error joining room:', error);
      socket.emit('error', { message: error.message });
    }
  });

  socket.on('disconnect', () => {
    console.log(`🔌 Client disconnected: ${socket.id}`);
    
    // Clean up peer from all rooms
    rooms.forEach((room, roomId) => {
      if (room.peers.has(socket.id)) {
        room.removePeer(socket.id);
        socket.to(roomId).emit('peer-left', { peerId: socket.id });
        
        // Clean up empty rooms
        if (room.peers.size === 0) {
          room.router.close();
          rooms.delete(roomId);
          console.log(`🧹 Cleaned up empty room: ${roomId}`);
        }
      }
    });
  });
});

// Health check endpoint
app.get('/', (req, res) => {
  res.json({
    message: 'Arena MediaSoup SFU Server',
    status: 'running',
    workers: mediasoupWorkers.length,
    rooms: rooms.size,
    timestamp: new Date().toISOString(),
    environment: process.env.NODE_ENV || 'production'
  });
});

// Start server
const PORT = process.env.PORT || 3001;

async function startServer() {
  try {
    await initializeMediaSoup();
    
    server.listen(PORT, '0.0.0.0', () => {
      console.log(`🚀 Arena MediaSoup SFU Server running on port ${PORT}`);
      console.log(`📊 Workers: ${mediasoupWorkers.length}`);
      console.log(`🌐 Environment: ${process.env.NODE_ENV || 'production'}`);
      console.log(`📡 Announced IP: ${process.env.ANNOUNCED_IP || '172.236.109.9'}`);
      console.log(`🎯 WebRTC ports: ${mediasoupConfig.worker.rtcMinPort}-${mediasoupConfig.worker.rtcMaxPort}`);
    });
  } catch (error) {
    console.error('❌ Failed to start MediaSoup server:', error);
    process.exit(1);
  }
}

startServer();